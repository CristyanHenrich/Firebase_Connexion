package com.example.firebaseapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {

    private DatabaseReference referencia = FirebaseDatabase.getInstance().getReference();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        



        /*

        //CONECTAR AO BANCO

        //DatabaseReference usuarios = referencia.child( "usuarios" ).child("001"); RECUPERA O NO EXPECIFICADO NO CASO O USUARIO 001
        DatabaseReference usuarios = referencia.child( "usuarios" );//RECUPERA TODOS OS DADOS DE USUARIO
        DatabaseReference produtos = referencia.child("produtos");

        //PUXAR DO BANCO

        usuarios.addValueEventListener(new ValueEventListener() {//ESCUTA EM TEMPO REAL O BANCO DE DADOS USUARIOS
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Log.i("FIREBASE", snapshot.getValue().toString() );//TRAS OS VALORES E CONVERTE EM STRING
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        //SALVAR NO BANCO VIA CLASSE

        Usuario usuario = new Usuario();
        usuario.setNome("Cristyan");
        usuario.setSobrenome("Henrich");
        usuario.setIdade(19);

        usuarios.child("002").setValue( usuario );


        Produtos produto = new Produtos();
        produto.setDescricao("Iphone 13");
        produto.setMarca("Apple");
        produto.setPreco(5000);

        produtos.child("002").setValue( produto );
         */


    }
}